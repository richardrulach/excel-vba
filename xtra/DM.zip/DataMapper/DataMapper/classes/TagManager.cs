﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace DataMapper
{
    public class TagManager
    {

        public TagManager()
        {

        }


        public List<db_tag> GetTags()
        {
            List<db_tag> lstReturn = new List<db_tag>();

            String conn = @"Server=.\localtest;Database=DataMapper;User Id=richard;Password=richard;";
            String sql = "select tag_id, tag_name from tag";

            SqlCommand runRulesCmd = new SqlCommand();
            SqlConnection sqlconnection = new SqlConnection(conn);

            runRulesCmd.Connection = sqlconnection;
            runRulesCmd.CommandText = sql;

            sqlconnection.Open();
            SqlDataReader dr = runRulesCmd.ExecuteReader();

            while (dr.Read())
            {
                lstReturn.Add(new db_tag(dr.GetValue(0).ToString(),dr.GetValue(1).ToString()));
            }
            dr.Close();

            return lstReturn;
        }

        public void AddTag(String tagName)
        {
            String conn = @"Server=.\localtest;Database=DataMapper;User Id=richard;Password=richard;";
            String sql = "insert into tag(tag_name) values('" + tagName + "')";

            SqlCommand runRulesCmd = new SqlCommand();
            SqlConnection sqlconnection = new SqlConnection(conn);

            runRulesCmd.Connection = sqlconnection;
            runRulesCmd.CommandText = sql;

            sqlconnection.Open();
            runRulesCmd.ExecuteNonQuery();
            sqlconnection.Close();
        }

        public void UpdateTag(String tagId, String tagName)
        {
            String conn = @"Server=.\localtest;Database=DataMapper;User Id=richard;Password=richard;";
            String sql = "update tag set tag_name = '" + tagName + "' where tag_id = " + tagId;

            SqlCommand runRulesCmd = new SqlCommand();
            SqlConnection sqlconnection = new SqlConnection(conn);

            runRulesCmd.Connection = sqlconnection;
            runRulesCmd.CommandText = sql;

            sqlconnection.Open();
            runRulesCmd.ExecuteNonQuery();
            sqlconnection.Close();
        }

        public void DeleteTag(String tagId)
        {
            String conn = @"Server=.\localtest;Database=DataMapper;User Id=richard;Password=richard;";
            String sql = "delete tag where tag_id = " + tagId;

            SqlCommand runRulesCmd = new SqlCommand();
            SqlConnection sqlconnection = new SqlConnection(conn);

            runRulesCmd.Connection = sqlconnection;
            runRulesCmd.CommandText = sql;

            sqlconnection.Open();
            runRulesCmd.ExecuteNonQuery();
            sqlconnection.Close();            
        }



    }
}