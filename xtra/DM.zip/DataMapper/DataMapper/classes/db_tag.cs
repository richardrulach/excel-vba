﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataMapper
{

    public class db_tag
    {
        public String tag_id = "";
        public String tag_name = "";

        public db_tag(String id, String name)
        {
            tag_id = id;
            tag_name = name;
        }

    }
}