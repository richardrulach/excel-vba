﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.Script.Serialization;

namespace DataMapper._srv
{
    public struct ArrayContainer
    {
        public List<db_tag> elements;
    }

    public struct iStruct
    {
        public string name;
        public string age;
    }

    /// <summary>
    /// Summary description for DM
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class DM : System.Web.Services.WebService
    {

        [WebMethod]
        public string DeleteTag(String tagId)
        {
            TagManager t = new TagManager();
            t.DeleteTag(tagId);

            ArrayContainer ac = new ArrayContainer();
            ac.elements = t.GetTags();

            return new JavaScriptSerializer().Serialize(ac);
        }

        [WebMethod]
        public string UpdateTag(String tagId, String tagName)
        {
            TagManager t = new TagManager();
            t.UpdateTag(tagId, tagName);

            ArrayContainer ac = new ArrayContainer();
            ac.elements = t.GetTags();

            return new JavaScriptSerializer().Serialize(ac);
        }

        [WebMethod]
        public string AddTag(String tagName)
        {
            TagManager t = new TagManager();
            t.AddTag(tagName);

            ArrayContainer ac = new ArrayContainer();
            ac.elements = t.GetTags();

            return new JavaScriptSerializer().Serialize(ac);
        }

        [WebMethod]

        public string GetTags()
        {
            TagManager t = new TagManager();
            ArrayContainer ac = new ArrayContainer();
            ac.elements = t.GetTags();

            return new JavaScriptSerializer().Serialize(ac);
        }
    }
}
