﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.Script.Serialization;

namespace DataMapper._srv
{
    public struct iStruct
    {
        public string name;
        public string age;
    }
    
    /// <summary>
    /// Summary description for DM
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class DM : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            List<iStruct> peeps = new List<iStruct>();

            iStruct r = new iStruct();
            r.name = "Richard";
            r.age = "41";

            iStruct s = new iStruct();
            s.name = "Steve";
            s.age = "42";

            peeps.Add(r);
            peeps.Add(s);

            return new JavaScriptSerializer().Serialize(peeps);
        }
    }
}
